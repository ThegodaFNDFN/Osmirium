﻿using MelonLoader;
using HarmonyLib;
using IIDKQuest.Classes;
using IIDKQuest.Notifications;
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using static IIDKQuest.Menu.Buttons;
using static IIDKQuest.Settings;
using UnhollowerRuntimeLib;
using IIDKQuest.Mods;
using Photon.Pun;

namespace IIDKQuest.Menu
{
    public class Main : MelonMod
    {
        public static GameObject menuOutline;
        public static Color menuOutlineColor = new Color(0f,0f,0f);
        public override void OnApplicationStart()
        {
            ClassInjector.RegisterTypeInIl2Cpp<NotifiLib>();
            ClassInjector.RegisterTypeInIl2Cpp<TimedBehaviour>();
            ClassInjector.RegisterTypeInIl2Cpp<RigManager>();
            ClassInjector.RegisterTypeInIl2Cpp<ColorChanger>();
            ClassInjector.RegisterTypeInIl2Cpp<IIDKQuest.Classes.Button>();
        }

        public override void OnUpdate()
        {
                try
                {
                    bool toOpen = (!rightHanded && easyInputs.EasyInputs.GetSecondaryButtonDown(easyInputs.EasyHand.LeftHand)) || (rightHanded && easyInputs.EasyInputs.GetSecondaryButtonDown(easyInputs.EasyHand.RightHand));
                bool keyboardOpen = false;

                    if (menu == null)
                    {
                        if (toOpen || keyboardOpen)
                        {
                            CreateMenu();
                            RecenterMenu(rightHanded, keyboardOpen);
                            if (reference == null)
                            {
                                CreateReference(rightHanded);
                            }
                        }
                    }
                    else
                    {
                        if ((toOpen || keyboardOpen))
                        {
                            RecenterMenu(rightHanded, keyboardOpen);
                        }
                        else
                        {
                            Rigidbody comp = menu.AddComponent(Il2CppType.From(typeof(Rigidbody))) as Rigidbody;

                            UnityEngine.Object.Destroy(menu, 3f);
                            menu = null;

                            UnityEngine.Object.Destroy(reference);
                            reference = null;
                        }
                    }
                }
                catch (Exception exc)
                {
                    UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
                }

            // Constant
                try
                {
                    // Pre-Execution
                        if (fpsObject != null)
                        {
                            fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                        }

                    // Execute Enabled mods
                        foreach (ButtonInfo[] buttonlist in buttons)
                        {
                            foreach (ButtonInfo v in buttonlist)
                            {
                                if (v.enabled)
                                {
                                    if (v.method != null)
                                    {
                                        try
                                        {
                                            v.method.Invoke();
                                        }
                                        catch (Exception exc)
                                        {
                                            UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", PluginInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                        }
                                    }
                                }
                            }
                        }
                } catch (Exception exc)
                {
                    UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
                }
        }
        public static void UpdateMenuOutlineColor(Color newColor)
        {
            menuOutlineColor = newColor;
            if (menuOutline == null) return;

            Renderer r = menuOutline.GetComponent<Renderer>();
            if (r != null)
            {
                r.material.color = menuOutlineColor;
            }
        }
        // Functions
        public static void CreateMenu()
        {
            // Menu Holder
                menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
                UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
                menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            // Menu Background
                menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
                menuBackground.transform.parent = menu.transform;
                menuBackground.transform.rotation = Quaternion.identity;
                menuBackground.transform.localScale = menuSize;
                menuBackground.GetComponent<Renderer>().material.color = backgroundColor.colors[0].color;
                menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);

                ColorChanger colorChanger = menuBackground.AddComponent<ColorChanger>();
                colorChanger.colorInfo = backgroundColor;
                colorChanger.Start();

            // MENU OUTLINE
            GameObject menuOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuOutline.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuOutline.GetComponent<BoxCollider>());
            menuOutline.transform.parent = menu.transform;
            menuOutline.transform.rotation = Quaternion.identity;

            menuOutline.transform.localScale = new Vector3(menuSize.x * 0.82f, menuSize.y * 1.06f, menuSize.z * 1.06f);
            menuOutline.transform.position = menuBackground.transform.position;

            Renderer menuOutlineRenderer = menuOutline.GetComponent<Renderer>();
            if (menuOutlineRenderer != null)
            {
                menuOutlineRenderer.material.color = Color.black;
                menuOutlineRenderer.enabled = true;
            }
            menuOutline.SetActive(true);

            // Canvas
            canvasObject = new GameObject();
                canvasObject.transform.parent = menu.transform;
                Canvas canvas = canvasObject.AddComponent<Canvas>();
                CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
                canvasObject.AddComponent<GraphicRaycaster>();
                canvas.renderMode = RenderMode.WorldSpace;
                canvasScaler.dynamicPixelsPerUnit = 1000f;

            // Title and FPS
                Text text = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                text.font = currentFont;
                text.text = PluginInfo.Name + " - <color=white>P" + (pageNumber + 1).ToString() + "</color>";
                text.fontSize = 1;
                text.color = textColors[0];
                text.supportRichText = true;
                text.fontStyle = FontStyle.Italic;
                text.alignment = TextAnchor.MiddleCenter;
                text.resizeTextForBestFit = true;
                text.resizeTextMinSize = 0;
                RectTransform component = text.GetComponent<RectTransform>();
                component.localPosition = Vector3.zero;
                component.sizeDelta = new Vector2(0.28f, 0.05f);
                component.position = new Vector3(0.06f, 0f, 0.165f);
                component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            // Buttons
            // Disconnect
            if (disconnectButton)
            {
                GameObject disconnectbutton = GameObject.CreatePrimitive(PrimitiveType.Cube);

                UnityEngine.Object.Destroy(disconnectbutton.GetComponent<Rigidbody>());
                disconnectbutton.GetComponent<BoxCollider>().isTrigger = true;
                disconnectbutton.transform.parent = menu.transform;
                disconnectbutton.transform.rotation = Quaternion.identity;
                disconnectbutton.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
                disconnectbutton.transform.localPosition = new Vector3(0.56f, 0f, 0.6f);
                disconnectbutton.GetComponent<Renderer>().material.color = buttonColors[0].colors[0].color;
                disconnectbutton.AddComponent<Classes.Button>().relatedText = "Disconnect";

                ColorChanger disconnect = disconnectbutton.AddComponent<ColorChanger>();
                disconnect.colorInfo = buttonColors[0];
                disconnect.Start();

                // Outline for Disconnect button
                GameObject disconnectOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(disconnectOutline.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(disconnectOutline.GetComponent<BoxCollider>());
                disconnectOutline.transform.parent = disconnectbutton.transform;
                disconnectOutline.transform.localRotation = Quaternion.identity;
                disconnectOutline.transform.localScale = new Vector3(
                    disconnectbutton.transform.localScale.x * 6f,
                    disconnectbutton.transform.localScale.y * 1.142f,
                    disconnectbutton.transform.localScale.z * 14f);
                disconnectOutline.transform.localPosition = Vector3.zero;

                Renderer disconnectOutlineRenderer = disconnectOutline.GetComponent<Renderer>();
                if (disconnectOutlineRenderer != null)
                {
                    disconnectOutlineRenderer.material.color = Color.black;
                    disconnectOutlineRenderer.enabled = true;
                }
                disconnectOutline.SetActive(true);

                Text discontext = new GameObject
                {
                    transform =
        {
            parent = canvasObject.transform
        }
                }.AddComponent<Text>();
                discontext.text = "Disconnect";
                discontext.font = currentFont;
                discontext.fontSize = 1;
                discontext.color = textColors[0];
                discontext.alignment = TextAnchor.MiddleCenter;
                discontext.resizeTextForBestFit = true;
                discontext.resizeTextMinSize = 0;

                RectTransform rectt = discontext.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.2f, 0.03f);
                rectt.localPosition = new Vector3(0.064f, 0f, 0.23f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }

            // Home Button
            GameObject disconnectbutton1 = GameObject.CreatePrimitive(PrimitiveType.Cube);

            UnityEngine.Object.Destroy(disconnectbutton1.GetComponent<Rigidbody>());
            disconnectbutton1.GetComponent<BoxCollider>().isTrigger = true;
            disconnectbutton1.transform.parent = menu.transform;
            disconnectbutton1.transform.rotation = Quaternion.identity;
            disconnectbutton1.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
            disconnectbutton1.transform.localPosition = new Vector3(0.56f, 0f, -0.6f);
            disconnectbutton1.GetComponent<Renderer>().material.color = buttonColors[0].colors[0].color;
            disconnectbutton1.AddComponent<Classes.Button>().relatedText = "Home";

            colorChanger = disconnectbutton1.AddComponent<ColorChanger>();
            colorChanger.colorInfo = buttonColors[0];
            colorChanger.Start();

            // Outline for Home button
            GameObject homeOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(homeOutline.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(homeOutline.GetComponent<BoxCollider>());
            homeOutline.transform.parent = disconnectbutton1.transform;
            homeOutline.transform.localRotation = Quaternion.identity;
            homeOutline.transform.localScale = new Vector3(
                disconnectbutton1.transform.localScale.x * 6f,
                disconnectbutton1.transform.localScale.y * 1.142f,
                disconnectbutton1.transform.localScale.z * 14f);
            homeOutline.transform.localPosition = Vector3.zero;

            Renderer homeOutlineRenderer = homeOutline.GetComponent<Renderer>();
            if (homeOutlineRenderer != null)
            {
                homeOutlineRenderer.material.color = Color.black;
                homeOutlineRenderer.enabled = true;
            }
            homeOutline.SetActive(true);

            Text discontext1 = new GameObject
            {
                transform =
    {
        parent = canvasObject.transform
    }
            }.AddComponent<Text>();
            discontext1.text = "Home";
            discontext1.font = currentFont;
            discontext1.fontSize = 1;
            discontext1.color = textColors[0];
            discontext1.alignment = TextAnchor.MiddleCenter;
            discontext1.resizeTextForBestFit = true;
            discontext1.resizeTextMinSize = 0;

            RectTransform rectt1 = discontext1.GetComponent<RectTransform>();
            rectt1.localPosition = Vector3.zero;
            rectt1.sizeDelta = new Vector2(0.2f, 0.03f);
            rectt1.localPosition = new Vector3(0.064f, 0f, -0.23f);
            rectt1.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));


            // Page Buttons
            // Previous Page Button
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);

            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, -0.32f);
            gameObject.GetComponent<Renderer>().material.color = buttonColors[0].colors[0].color;
            gameObject.AddComponent<Classes.Button>().relatedText = "PreviousPage";

            colorChanger = gameObject.AddComponent<ColorChanger>();
            colorChanger.colorInfo = buttonColors[0];
            colorChanger.Start();

            // Outline for Previous Page Button
            GameObject buttonOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<BoxCollider>());
            buttonOutline.transform.parent = gameObject.transform;
            buttonOutline.transform.rotation = Quaternion.identity;
            buttonOutline.transform.localPosition = Vector3.zero;
            buttonOutline.transform.localScale = new Vector3(0.09f * 6f, 0.9f * 1.142f, 0.08f * 14f);

            Renderer outlineRenderer = buttonOutline.GetComponent<Renderer>();
            outlineRenderer.material.color = Color.black;
            outlineRenderer.enabled = true;

            // Text for Previous Page Button
            text = new GameObject
            {
                transform =
    {
        parent = canvasObject.transform
    }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = "<<";
            text.fontSize = 1;
            text.color = textColors[0];
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0f, -0.1198f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            // Next Page Button
            gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);

            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, -0.42f);
            gameObject.GetComponent<Renderer>().material.color = buttonColors[0].colors[0].color;
            gameObject.AddComponent<Classes.Button>().relatedText = "NextPage";

            colorChanger = gameObject.AddComponent<ColorChanger>();
            colorChanger.colorInfo = buttonColors[0];
            colorChanger.Start();

            // Outline for Next Page Button
            buttonOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<BoxCollider>());
            buttonOutline.transform.parent = gameObject.transform;
            buttonOutline.transform.rotation = Quaternion.identity;
            buttonOutline.transform.localPosition = Vector3.zero;
            buttonOutline.transform.localScale = new Vector3(0.09f * 6f, 0.9f * 1.142f, 0.08f * 14f);

            outlineRenderer = buttonOutline.GetComponent<Renderer>();
            outlineRenderer.material.color = Color.black;
            outlineRenderer.enabled = true;

            // Text for Next Page Button
            text = new GameObject
            {
                transform =
    {
        parent = canvasObject.transform
    }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = ">>";
            text.fontSize = 1;
            text.color = textColors[0];
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0f, -0.1582f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));


            // Mod Buttons
            ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
                    for (int i = 0; i < activeButtons.Length; i++)
                    {
                        CreateButton(i * 0.1f, activeButtons[i]);
                    }
        }

        public static void CreateButton(float offset, ButtonInfo method)
        {
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);

            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.28f - offset);
            gameObject.AddComponent<Classes.Button>().relatedText = method.buttonText;

            ColorChanger colorChanger = gameObject.AddComponent<ColorChanger>();
            if (method.enabled)
            {
                colorChanger.colorInfo = buttonColors[1];
            }
            else
            {
                colorChanger.colorInfo = buttonColors[0];
            }
            colorChanger.Start();

            // --- BUTTON OUTLINE ---
            GameObject buttonOutline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(buttonOutline.GetComponent<BoxCollider>());
            buttonOutline.transform.parent = gameObject.transform;
            buttonOutline.transform.rotation = Quaternion.identity;
            buttonOutline.transform.localScale = new Vector3(
                gameObject.transform.localScale.x * 6f,
                gameObject.transform.localScale.y * 1.142f,
                gameObject.transform.localScale.z * 14f
            );

            buttonOutline.transform.localPosition = Vector3.zero;

            Renderer buttonOutlineRenderer = buttonOutline.GetComponent<Renderer>();
            if (buttonOutlineRenderer != null)
            {
                buttonOutlineRenderer.material.color = Color.black;
                buttonOutlineRenderer.enabled = true;
            }
            buttonOutline.SetActive(true);

            Text text = new GameObject
            {
                transform =
        {
            parent = canvasObject.transform
        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = method.buttonText;
            if (method.overlapText != null)
            {
                text.text = method.overlapText;
            }
            text.supportRichText = true;
            text.fontSize = 1;
            if (method.enabled)
            {
                text.color = textColors[1];
            }
            else
            {
                text.color = textColors[0];
            }
            text.alignment = TextAnchor.MiddleCenter;
            text.fontStyle = FontStyle.Italic;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(.2f, .03f);
            component.localPosition = new Vector3(.064f, 0, .111f - offset / 2.6f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }



        public static void RecreateMenu()
        {
            if (menu != null)
            {
                UnityEngine.Object.Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(rightHanded, false);
            }
        }

        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                }
                else
                {
                    menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Vector3 rotation = GorillaTagger.Instance.rightHandTransform.rotation.eulerAngles;
                    rotation += new Vector3(0f, 0f, 180f);
                    menu.transform.rotation = Quaternion.Euler(rotation);
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }
                if (TPC != null)
                {
                    TPC.transform.position = new Vector3(-999f, -999f, -999f);
                    TPC.transform.rotation = Quaternion.identity;
                    GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    bg.transform.localScale = new Vector3(10f, 10f, 0.01f);
                    bg.transform.transform.position = TPC.transform.position + TPC.transform.forward;
                    bg.GetComponent<Renderer>().material.color = new Color32((byte)(backgroundColor.colors[0].color.r * 50), (byte)(backgroundColor.colors[0].color.g * 50), (byte)(backgroundColor.colors[0].color.b * 50), 255);
                    GameObject.Destroy(bg, Time.deltaTime);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);

                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                            RaycastHit hit;
                            bool worked = Physics.Raycast(ray, out hit, 100);
                            if (worked)
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }

        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = backgroundColor.colors[0].color;
            reference.transform.localPosition = new Vector3(0.018f, -0.008f, 0.1f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();

            ColorChanger colorChanger = reference.AddComponent<ColorChanger>();
            colorChanger.colorInfo = backgroundColor;
            colorChanger.Start();
        }

        public static void Toggle(string buttonText)
        {
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "Disconnect")
            {
                PhotonNetwork.Disconnect();
            }
            if (buttonText == "Home")
            {
                pageNumber = 0;
                Global.ReturnHome();
            }
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError(buttonText + " does not exist");
                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }

        // Variables
            // Important
                // Objects
                    public static GameObject menu;
                    public static GameObject menuBackground;   
                    public static GameObject reference;
                    public static GameObject canvasObject;

                    public static SphereCollider buttonCollider;
                    public static Camera TPC;
                    public static Text fpsObject;

        // Data
            public static int pageNumber = 0;
            public static int buttonsType = 0;
    }
}
