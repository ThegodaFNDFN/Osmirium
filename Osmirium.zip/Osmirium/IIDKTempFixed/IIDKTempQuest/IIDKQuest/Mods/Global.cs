﻿using static IIDKQuest.Menu.Main;

namespace IIDKQuest.Mods
{
    internal class Global
    {
        public static void ReturnHome()
        {
            buttonsType = 0;
        }
    }
}
