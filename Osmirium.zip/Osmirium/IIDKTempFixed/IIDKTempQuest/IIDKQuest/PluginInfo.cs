﻿namespace IIDKQuest
{
    internal class PluginInfo
    {
        public const string GUID = "org.iidk.gorillatag.menutemplate";
        public const string Name = "Osmirium";
        public const string Description = "A Menu thats open source";
        public const string Version = "1.0.0";
    }
}
